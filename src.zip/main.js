"use strict";
(self["webpackChunkmain_sidebar"] = self["webpackChunkmain_sidebar"] || []).push([["main"],{

/***/ 4967:
/*!*********************************************!*\
  !*** ./projects/core/src/core.component.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CoreComponent": () => (/* binding */ CoreComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);

class CoreComponent {}
CoreComponent.ɵfac = function CoreComponent_Factory(t) {
  return new (t || CoreComponent)();
};
CoreComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: CoreComponent,
  selectors: [["app-core"]],
  decls: 0,
  vars: 0,
  template: function CoreComponent_Template(rf, ctx) {},
  styles: ["\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsInNvdXJjZVJvb3QiOiIifQ== */"],
  encapsulation: 2
});

/***/ }),

/***/ 9570:
/*!******************************************!*\
  !*** ./projects/core/src/core.module.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CoreModule": () => (/* binding */ CoreModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _core_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./core.component */ 4967);
/* harmony import */ var _shared_interceptors_apiKey_api_key_interceptor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shared/interceptors/apiKey/api-key.interceptor */ 4109);
/* harmony import */ var _shared_dialogs_module_controls_module_controls_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./shared/dialogs/module-controls/module-controls.module */ 6665);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! primeng/dynamicdialog */ 2648);
/* harmony import */ var _shared_services_system_system_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./shared/services/system/system.service */ 7738);









class CoreModule {
  static forRoot(configuration) {
    return {
      ngModule: CoreModule,
      providers: [{
        provide: 'config',
        useValue: configuration.api
      }]
    };
  }
}
CoreModule.ɵfac = function CoreModule_Factory(t) {
  return new (t || CoreModule)();
};
CoreModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: CoreModule
});
CoreModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  providers: [primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_1__.DialogService, [{
    provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HTTP_INTERCEPTORS,
    useClass: _shared_interceptors_apiKey_api_key_interceptor__WEBPACK_IMPORTED_MODULE_3__.ApiKeyInterceptor,
    multi: true
  }], {
    provide: _angular_core__WEBPACK_IMPORTED_MODULE_0__.APP_INITIALIZER,
    useFactory: service => function () {
      return service.init();
    },
    deps: [_shared_services_system_system_service__WEBPACK_IMPORTED_MODULE_4__.SystemService],
    multi: true
  }],
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClientModule, _shared_dialogs_module_controls_module_controls_module__WEBPACK_IMPORTED_MODULE_6__.ModuleControlsModule]
});
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](CoreModule, {
    declarations: [_core_component__WEBPACK_IMPORTED_MODULE_7__.CoreComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClientModule, _shared_dialogs_module_controls_module_controls_module__WEBPACK_IMPORTED_MODULE_6__.ModuleControlsModule]
  });
})();

/***/ }),

/***/ 6897:
/*!***************************************************************************************!*\
  !*** ./projects/core/src/shared/dialogs/module-controls/module-controls.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModuleControlsComponent": () => (/* binding */ ModuleControlsComponent)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/dynamicdialog */ 2648);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/button */ 6328);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/inputtext */ 9906);






class ModuleControlsComponent {
  constructor(ref) {
    this.ref = ref;
    this.createModuleForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormGroup({
      label: new _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.required]),
      identifier: new _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.Validators.pattern(/[a-z]/)])
    });
  }
  onClose() {
    this.ref.close(this.createModuleForm.value);
  }
}
ModuleControlsComponent.ɵfac = function ModuleControlsComponent_Factory(t) {
  return new (t || ModuleControlsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_2__.DynamicDialogRef));
};
ModuleControlsComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
  type: ModuleControlsComponent,
  selectors: [["lib-module-controls"]],
  decls: 8,
  vars: 4,
  consts: [[1, "app-dialog"], [1, "modal-form", 3, "formGroup"], [1, "p-fluid", "p-field"], ["pInputText", "", "formControlName", "label", 3, "placeholder"], ["pInputText", "", "formControlName", "identifier", 3, "placeholder"], [1, "app-dialog__footer", "align-right"], ["icon", "pi pi-check", "label", "Create", "styleClass", "p-button-text", 3, "disabled", "onClick"]],
  template: function ModuleControlsComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "form", 1)(2, "span", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "input", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "span", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "input", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "div", 5)(7, "p-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("onClick", function ModuleControlsComponent_Template_p_button_onClick_7_listener() {
        return ctx.onClose();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    }
    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("formGroup", ctx.createModuleForm);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("placeholder", "Module label");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("placeholder", "Module id");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("disabled", ctx.createModuleForm.invalid);
    }
  },
  dependencies: [primeng_button__WEBPACK_IMPORTED_MODULE_3__.Button, _angular_forms__WEBPACK_IMPORTED_MODULE_0__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_0__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormGroupDirective, _angular_forms__WEBPACK_IMPORTED_MODULE_0__.FormControlName, primeng_inputtext__WEBPACK_IMPORTED_MODULE_4__.InputText],
  styles: [".app-dialog[_ngcontent-%COMP%] {\n  min-width: 320px;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3Byb2plY3RzL2NvcmUvc3JjL3NoYXJlZC9kaWFsb2dzL21vZHVsZS1jb250cm9scy9tb2R1bGUtY29udHJvbHMuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLi8uLi8uLi8uLi8uLi8uLi8lRDAlOUElRDAlQjglRDElODAlRDAlQjglRDAlQkIlRDAlQkIvRGVza3RvcC8lRDAlOTElRDElODMlRDElODUlRDAlQjMlRDAlQjAlRDAlQkIlRDElODIlRDAlQjUlRDElODAlRDAlQjglRDElOEYlMjBNb2R1bGVzL21haW4tc2lkZWJhci9kZXYvcHJvamVjdHMvY29yZS9zcmMvc2hhcmVkL2RpYWxvZ3MvbW9kdWxlLWNvbnRyb2xzL21vZHVsZS1jb250cm9scy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0FDQ0oiLCJzb3VyY2VzQ29udGVudCI6WyIuYXBwLWRpYWxvZyB7XHJcbiAgICBtaW4td2lkdGg6IDMyMHB4O1xyXG59IiwiLmFwcC1kaWFsb2cge1xuICBtaW4td2lkdGg6IDMyMHB4O1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
});

/***/ }),

/***/ 6665:
/*!************************************************************************************!*\
  !*** ./projects/core/src/shared/dialogs/module-controls/module-controls.module.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModuleControlsModule": () => (/* binding */ ModuleControlsModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _module_controls_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./module-controls.component */ 6897);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeng/dialog */ 1837);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/button */ 6328);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/inputtext */ 9906);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);







class ModuleControlsModule {}
ModuleControlsModule.ɵfac = function ModuleControlsModule_Factory(t) {
  return new (t || ModuleControlsModule)();
};
ModuleControlsModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: ModuleControlsModule
});
ModuleControlsModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_2__.DialogModule, primeng_button__WEBPACK_IMPORTED_MODULE_3__.ButtonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.ReactiveFormsModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_5__.InputTextModule]
});
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](ModuleControlsModule, {
    declarations: [_module_controls_component__WEBPACK_IMPORTED_MODULE_6__.ModuleControlsComponent],
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_2__.DialogModule, primeng_button__WEBPACK_IMPORTED_MODULE_3__.ButtonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.ReactiveFormsModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_5__.InputTextModule],
    exports: [_module_controls_component__WEBPACK_IMPORTED_MODULE_6__.ModuleControlsComponent]
  });
})();

/***/ }),

/***/ 4109:
/*!*****************************************************************************!*\
  !*** ./projects/core/src/shared/interceptors/apiKey/api-key.interceptor.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiKeyInterceptor": () => (/* binding */ ApiKeyInterceptor)
/* harmony export */ });
/* harmony import */ var C_Users_Desktop_Modules_main_sidebar_dev_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 9346);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 8611);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var projects_core_src_shared_services_api_api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! projects/core/src/shared/services/api/api.service */ 18);
/* harmony import */ var _services_system_system_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../services/system/system.service */ 7738);





class ApiKeyInterceptor {
  constructor(apiService, systemService) {
    this.apiService = apiService;
    this.systemService = systemService;
  }
  intercept(request, next) {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.from)(this.handle(request, next));
  }
  handle(request, next) {
    var _this = this;
    return (0,C_Users_Desktop_Modules_main_sidebar_dev_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const apiKey = _this.apiService.apiKey;
      request = request.clone({
        setHeaders: {
          apikey: apiKey,
          Accept: 'application/json'
        }
      });
      return yield (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.lastValueFrom)(next.handle(request));
    })();
  }
}
ApiKeyInterceptor.ɵfac = function ApiKeyInterceptor_Factory(t) {
  return new (t || ApiKeyInterceptor)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](projects_core_src_shared_services_api_api_service__WEBPACK_IMPORTED_MODULE_4__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_services_system_system_service__WEBPACK_IMPORTED_MODULE_5__.SystemService));
};
ApiKeyInterceptor.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: ApiKeyInterceptor,
  factory: ApiKeyInterceptor.ɵfac
});

/***/ }),

/***/ 18:
/*!**************************************************************!*\
  !*** ./projects/core/src/shared/services/api/api.service.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiService": () => (/* binding */ ApiService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);



class ApiService {
  constructor(config, http) {
    this.http = http;
    const {
      key,
      url
    } = config;
    if (!key) {
      throw new Error('Invalid api key');
    }
    this.key = key;
    this.apiUrl = url;
  }
  get apiKey() {
    return this.key;
  }
  set apiKey(value) {
    this.key = value;
  }
  getModules(filter = {}) {
    return this.http.get(`${this.apiUrl}/modules/fetch`, {
      params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpParams({
        fromObject: {
          filter: JSON.stringify(filter)
        }
      })
    });
  }
  getCurrentCompany() {
    return this.http.get(`${this.apiUrl}/companies/current`);
  }
  navigateTo(url) {
    url = Array.isArray(url) ? url.join('/') : url;
    window.parent.postMessage({
      action: 'navigateTo',
      url: url
    }, 'http://localhost:4200/content');
  }
  createModule(data) {
    return this.http.post(`${this.apiKey}/modules`, data);
  }
}
ApiService.ɵfac = function ApiService_Factory(t) {
  return new (t || ApiService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"]('config'), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpClient));
};
ApiService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
  token: ApiService,
  factory: ApiService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 2821:
/*!**********************************************************************!*\
  !*** ./projects/core/src/shared/services/dialogs/dialogs.service.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DialogsService": () => (/* binding */ DialogsService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 3280);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 9337);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! primeng/dynamicdialog */ 2648);



class DialogsService {
  constructor(dialogService) {
    this.dialogService = dialogService;
  }
  open(dialogName, data) {
    window.postMessage({
      action: dialogName,
      ...data
    });
    return {
      onClose: (0,rxjs__WEBPACK_IMPORTED_MODULE_0__.fromEvent)(window, 'message').pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_1__.tap)(response => response.data))
    };
  }
}
DialogsService.ɵfac = function DialogsService_Factory(t) {
  return new (t || DialogsService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](primeng_dynamicdialog__WEBPACK_IMPORTED_MODULE_3__.DialogService));
};
DialogsService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
  token: DialogsService,
  factory: DialogsService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 7738:
/*!********************************************************************!*\
  !*** ./projects/core/src/shared/services/system/system.service.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SystemService": () => (/* binding */ SystemService)
/* harmony export */ });
/* harmony import */ var C_Users_Desktop_Modules_main_sidebar_dev_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 8611);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 8987);




class SystemService {
  constructor(config, http) {
    this.http = http;
    const {
      url
    } = config;
    this.apiUrl = url;
  }
  init() {
    var _this = this;
    return (0,C_Users_Desktop_Modules_main_sidebar_dev_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        company
      } = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.lastValueFrom)(_this.getCurrentCompany());
      const {
        user
      } = yield (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.lastValueFrom)(_this.getCurrentUser());
      _this.currentCompany = company;
      _this.currentUser = user;
    })();
  }
  getCurrentCompany() {
    return this.http.get(`${this.apiUrl}/companies/current`);
  }
  getCurrentUser() {
    return this.http.get(`${this.apiUrl}/users/current`);
  }
  addTab(tabData) {
    window.parent.postMessage({
      action: 'addTab',
      tabData: tabData
    }, 'http://localhost:4200/content');
  }
}
SystemService.ɵfac = function SystemService_Factory(t) {
  return new (t || SystemService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"]('config'), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient));
};
SystemService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
  token: SystemService,
  factory: SystemService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 6078);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var projects_core_src_shared_services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! projects/core/src/shared/services/api/api.service */ 18);
/* harmony import */ var projects_core_src_shared_services_system_system_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! projects/core/src/shared/services/system/system.service */ 7738);
/* harmony import */ var projects_core_src_shared_services_dialogs_dialogs_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! projects/core/src/shared/services/dialogs/dialogs.service */ 2821);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/button */ 6328);
/* harmony import */ var primeng_divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/divider */ 1154);








function AppComponent_div_1_ng_container_10_li_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "li", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_div_1_ng_container_10_li_1_Template_li_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r8);
      const module_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r6.openModule(module_r4));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "a", 13)(2, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, " folder_open ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const module_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", module_r4.label, " ");
  }
}
function AppComponent_div_1_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, AppComponent_div_1_ng_container_10_li_1_Template, 5, 1, "li", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const module_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", module_r4.settings.moduleType === "custom");
  }
}
function AppComponent_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 3)(1, "div", 4)(2, "div", 5)(3, "p", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](6, "p-button", 8)(7, "p-button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](8, "p-divider");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](9, "ul", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](10, AppComponent_div_1_ng_container_10_Template, 2, 1, "ng-container", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "div", 4)(12, "ul", 10)(13, "li", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function AppComponent_div_1_Template_li_click_13_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r10.navigateTo("configurator"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](14, "a", 13)(15, "span", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](16, " toggle_on ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](17, " \u041A\u043E\u043D\u0444\u0438\u0433\u0443\u0440\u0430\u0442\u043E\u0440 ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](18, "div", 15)(19, "p-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("onClick", function AppComponent_div_1_Template_p_button_onClick_19_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r11);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r12.onCreateModule());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"](" ", ctx_r0.systemService.currentCompany.name, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx_r0.modules);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("label", "Create new module");
  }
}
function AppComponent_ng_template_2_Template(rf, ctx) {}
class AppComponent {
  constructor(apiService, systemService, dialogsService) {
    this.apiService = apiService;
    this.systemService = systemService;
    this.dialogsService = dialogsService;
    this.subscription = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subscription();
    this.modules = [];
    this.loadingConfig = {
      isLoadingData: false
    };
  }
  ngOnInit() {
    this.fetchModules();
  }
  fetchModules() {
    this.subscription.add(this.apiService.getModules({}).subscribe({
      next: ({
        modules
      }) => {
        this.modules = modules;
      }
    }));
  }
  onCreateModule() {
    this.subscription.add(this.dialogsService.open('createModule', {
      mode: 'create'
    }).onClose.subscribe({
      next: result => {
        if (result) {
          this.createModule(result);
        }
      }
    }));
  }
  createModule(data) {
    this.subscription.add(this.apiService.createModule(data).subscribe({
      next: () => {
        this.fetchModules();
      }
    }));
  }
  openModule(module) {
    const url = `content/${module.identifier}`;
    this.navigateTo(url);
    this.systemService.addTab({
      label: module.label,
      routerLink: url
    });
  }
  navigateTo(url) {
    this.apiService.navigateTo(url);
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
AppComponent.ɵfac = function AppComponent_Factory(t) {
  return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](projects_core_src_shared_services_api_api_service__WEBPACK_IMPORTED_MODULE_2__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](projects_core_src_shared_services_system_system_service__WEBPACK_IMPORTED_MODULE_3__.SystemService), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](projects_core_src_shared_services_dialogs_dialogs_service__WEBPACK_IMPORTED_MODULE_4__.DialogsService));
};
AppComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({
  type: AppComponent,
  selectors: [["app-root"]],
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵProvidersFeature"]([])],
  decls: 4,
  vars: 2,
  consts: [[1, "sidebar"], ["class", "sidebar__wrapper", 4, "ngIf", "ngIfElse"], ["loading", ""], [1, "sidebar__wrapper"], [1, "sidebar__part"], [1, "sidebar__info"], [1, "sidebar__info-company-name"], [1, "sidebar__controls"], ["icon", "pi pi-cog", "styleClass", "p-button-text"], ["icon", "pi pi-ellipsis-v", "styleClass", "p-button-text"], [1, "sidebar__list"], [4, "ngFor", "ngForOf"], [1, "sidebar__list--element", 3, "click"], [1, "sidebar__list--link"], [1, "material-icons"], [1, "p-fluid"], ["icon", "pi pi-plus", 3, "label", "onClick"], ["class", "sidebar__list--element", 3, "click", 4, "ngIf"]],
  template: function AppComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, AppComponent_div_1_Template, 20, 3, "div", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, AppComponent_ng_template_2_Template, 0, 0, "ng-template", null, 2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    }
    if (rf & 2) {
      const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", !ctx.loadingConfig.isLoadingData)("ngIfElse", _r1);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, primeng_button__WEBPACK_IMPORTED_MODULE_6__.Button, primeng_divider__WEBPACK_IMPORTED_MODULE_7__.Divider],
  styles: [".sidebar[_ngcontent-%COMP%] {\n  width: 320px;\n  background: #f5f5f5;\n  height: 100vh;\n  max-height: 100vh;\n}\n\n.sidebar__wrapper[_ngcontent-%COMP%] {\n  padding: 10px 15px;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  justify-content: space-between;\n}\n\n.sidebar__info[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.sidebar__info-company-name[_ngcontent-%COMP%] {\n  margin: 0;\n  font-weight: 400;\n  font-size: 1.6rem;\n}\n\n.sidebar__list[_ngcontent-%COMP%] {\n  margin-top: 25px;\n}\n\n.sidebar__list--link[_ngcontent-%COMP%] {\n  display: flex;\n  gap: 10px;\n  align-items: center;\n}\n\n.sidebar__list--element[_ngcontent-%COMP%] {\n  margin: 5px 0;\n  padding: 10px 10px;\n  transition: background 0.3s;\n  cursor: pointer;\n  border-radius: 5px;\n  background: #e7e7e7;\n}\n.sidebar__list--element[_ngcontent-%COMP%]:hover {\n  background: #d8d8d8;\n}\n.sidebar__list--element.active[_ngcontent-%COMP%] {\n  background: var(--main-color);\n  color: white;\n}\n\n.sidebar__controls[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwid2VicGFjazovLy4vLi4vLi4vLi4vLi4vLi4vJUQwJTlBJUQwJUI4JUQxJTgwJUQwJUI4JUQwJUJCJUQwJUJCL0Rlc2t0b3AvJUQwJTkxJUQxJTgzJUQxJTg1JUQwJUIzJUQwJUIwJUQwJUJCJUQxJTgyJUQwJUI1JUQxJTgwJUQwJUI4JUQxJThGJTIwTW9kdWxlcy9tYWluLXNpZGViYXIvZGV2L3NyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSw4QkFBQTtBQ0NKOztBREVBO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURFQTtFQUNJLFNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUE7RUFDSSxnQkFBQTtBQ0NKOztBREdBO0VBQ0ksYUFBQTtFQUNBLFNBQUE7RUFDQSxtQkFBQTtBQ0FKOztBRElBO0VBQ0ksYUFBQTtFQUNBLGtCQUFBO0VBQ0EsMkJBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0RKO0FER0k7RUFDSSxtQkFBQTtBQ0RSO0FESUk7RUFDSSw2QkFBQTtFQUNBLFlBQUE7QUNGUjs7QURNQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQ0hKIiwic291cmNlc0NvbnRlbnQiOlsiLnNpZGViYXIge1xyXG4gICAgd2lkdGg6IDMyMHB4O1xyXG4gICAgYmFja2dyb3VuZDogI2Y1ZjVmNTtcclxuICAgIGhlaWdodDogMTAwdmg7XHJcbiAgICBtYXgtaGVpZ2h0OiAxMDB2aDtcclxufVxyXG5cclxuLnNpZGViYXJfX3dyYXBwZXIge1xyXG4gICAgcGFkZGluZzogMTBweCAxNXB4O1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbn1cclxuXHJcbi5zaWRlYmFyX19pbmZvIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uc2lkZWJhcl9faW5mby1jb21wYW55LW5hbWUge1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIGZvbnQtc2l6ZTogMS42cmVtO1xyXG59XHJcblxyXG4uc2lkZWJhcl9fbGlzdCB7XHJcbiAgICBtYXJnaW4tdG9wOiAyNXB4O1xyXG5cclxufVxyXG5cclxuLnNpZGViYXJfX2xpc3QtLWxpbmsge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGdhcDogMTBweDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcblxyXG4uc2lkZWJhcl9fbGlzdC0tZWxlbWVudCB7XHJcbiAgICBtYXJnaW46IDVweCAwO1xyXG4gICAgcGFkZGluZzogMTBweCAxMHB4O1xyXG4gICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwLjNzO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgYmFja2dyb3VuZDogI2U3ZTdlNztcclxuXHJcbiAgICAmOmhvdmVyIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjZDhkOGQ4O1xyXG4gICAgfVxyXG5cclxuICAgICYuYWN0aXZlIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1tYWluLWNvbG9yKTtcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5zaWRlYmFyX19jb250cm9scyB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufSIsIi5zaWRlYmFyIHtcbiAgd2lkdGg6IDMyMHB4O1xuICBiYWNrZ3JvdW5kOiAjZjVmNWY1O1xuICBoZWlnaHQ6IDEwMHZoO1xuICBtYXgtaGVpZ2h0OiAxMDB2aDtcbn1cblxuLnNpZGViYXJfX3dyYXBwZXIge1xuICBwYWRkaW5nOiAxMHB4IDE1cHg7XG4gIGhlaWdodDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuXG4uc2lkZWJhcl9faW5mbyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLnNpZGViYXJfX2luZm8tY29tcGFueS1uYW1lIHtcbiAgbWFyZ2luOiAwO1xuICBmb250LXdlaWdodDogNDAwO1xuICBmb250LXNpemU6IDEuNnJlbTtcbn1cblxuLnNpZGViYXJfX2xpc3Qge1xuICBtYXJnaW4tdG9wOiAyNXB4O1xufVxuXG4uc2lkZWJhcl9fbGlzdC0tbGluayB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGdhcDogMTBweDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLnNpZGViYXJfX2xpc3QtLWVsZW1lbnQge1xuICBtYXJnaW46IDVweCAwO1xuICBwYWRkaW5nOiAxMHB4IDEwcHg7XG4gIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4zcztcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIGJhY2tncm91bmQ6ICNlN2U3ZTc7XG59XG4uc2lkZWJhcl9fbGlzdC0tZWxlbWVudDpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICNkOGQ4ZDg7XG59XG4uc2lkZWJhcl9fbGlzdC0tZWxlbWVudC5hY3RpdmUge1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1tYWluLWNvbG9yKTtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uc2lkZWJhcl9fY29udHJvbHMge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xufSJdLCJzb3VyY2VSb290IjoiIn0= */"]
});

/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var primeng_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primeng/button */ 6328);
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primeng/dialog */ 1837);
/* harmony import */ var primeng_divider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primeng/divider */ 1154);
/* harmony import */ var primeng_inputtext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primeng/inputtext */ 9906);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ 7146);
/* harmony import */ var projects_core_src_core_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../projects/core/src/core.module */ 9570);












class AppModule {}
AppModule.ɵfac = function AppModule_Factory(t) {
  return new (t || AppModule)();
};
AppModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({
  type: AppModule,
  bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent]
});
AppModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({
  imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__.BrowserModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__.BrowserAnimationsModule, primeng_button__WEBPACK_IMPORTED_MODULE_4__.ButtonModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_5__.DialogModule, primeng_divider__WEBPACK_IMPORTED_MODULE_6__.DividerModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_7__.InputTextModule, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule, projects_core_src_core_module__WEBPACK_IMPORTED_MODULE_9__.CoreModule.forRoot({
    api: {
      key: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NGFlZGY2YmRmMWRhOTkwZWI0MmI1YjQiLCJjb21wYW55SWQiOiI2NGFmZmQ4ZDhlYjFkMzJhODBlM2I0YWIiLCJ3b3Jrc3BhY2VOYW1lIjoiam91cm5leSIsImlhdCI6MTY5MDU2MjAxMSwiZXhwIjoxNzE2NDgyMDExfQ.BRZ-3OIJ4qMpoH0CbEFr05mHfQKV4r1nZlKOuWiXv8U',
      url: (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.isDevMode)() ? 'http://localhost:80/api/v1' : 'http://localhost:80/api/v1'
    }
  })]
});
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsetNgModuleScope"](AppModule, {
    declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__.BrowserModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__.BrowserAnimationsModule, primeng_button__WEBPACK_IMPORTED_MODULE_4__.ButtonModule, primeng_dialog__WEBPACK_IMPORTED_MODULE_5__.DialogModule, primeng_divider__WEBPACK_IMPORTED_MODULE_6__.DividerModule, primeng_inputtext__WEBPACK_IMPORTED_MODULE_7__.InputTextModule, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule, projects_core_src_core_module__WEBPACK_IMPORTED_MODULE_9__.CoreModule]
  });
})();

/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);


_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule).catch(err => console.error(err));

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map